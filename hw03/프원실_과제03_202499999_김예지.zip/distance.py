x1 = 0
y1 = 0
x2 = 3
y2 = 4

distance = ((x2 - x1)**2+(y2 - y1)**2)**0.5
print("두지점사이의거리", distance)